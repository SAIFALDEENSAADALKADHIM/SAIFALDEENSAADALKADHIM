import './SectionHead.css'

export default function SectionHead({ num, title, em, sub }) {
  return (
    <div className="s-head">
      <div className="s-num"><span className="slash">§</span> {num}</div>
      <div>
        <h2 className="s-title">{title} {em && <em>— {em}</em>}</h2>
        {sub && <p className="s-sub">{sub}</p>}
      </div>
    </div>
  )
}
