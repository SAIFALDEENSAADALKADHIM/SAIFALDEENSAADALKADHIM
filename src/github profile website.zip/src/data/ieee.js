export const IEEE_WORK = {
  roles: [
    { k: 'Vice Chair', v: 'IEEE P2418.11 Working Group — Blockchain-based Physical Digital Assets' },
    { k: 'Chair',      v: 'IEEE Young Professionals — Iraq Section' },
  ],
  standard: 'Standard for Framework of Blockchain-based Physical Digital Assets',
  pillars: [
    { k: 'Security via DLT',     v: 'Blockchain protocols for immutable voter registration and ballot casting.' },
    { k: 'Real-time auditing',   v: 'Audit trails for immediate detection of suspicious activities.' },
    { k: 'Verifiability',        v: 'Secure aggregation and public verification of physical digital asset transactions.' },
  ],
  awards: [
    '2022 — IEEE PES Day Best Ambassador',
    '2022 — IEEE Day Ambassador',
    'IEEE PES Young Professionals — content writer',
  ],
};
