export const PARTNERSHIPS = {
  role: 'Partnership Coordinator — IEEE PES Young Professionals',
  tagline: 'Powering the future of energy through strategic collaboration.',
  who: 'IEEE PES Young Professionals are a global community of early-career engineers advancing power & energy through technical expertise, professional development, and cross-border networking.',
  focus2026: [
    { k: 'Smart grids & microgrids',       v: 'Resilient, efficient energy distribution at local and regional scale.' },
    { k: 'Renewable integration',          v: 'Solar, wind, and hybrid renewable sources into existing grids.' },
    { k: 'Energy storage',                 v: 'Advanced storage technologies for grid stability and reliability.' },
    { k: 'EVs & charging infrastructure',  v: 'Deployment of electric vehicles and supporting charging networks.' },
    { k: 'Cybersecurity in power systems', v: 'Defending the power & energy sector against emerging threats.' },
    { k: 'Power system modernization',     v: 'Applying new technologies to modernize legacy infrastructure.' },
  ],
  collab: [
    'Joint research projects', 'Industry workshops & seminars', 'Mentorship programs',
    'Sponsorship opportunities', 'Technical presentations', 'Career development resources', 'Networking events',
  ],
};
