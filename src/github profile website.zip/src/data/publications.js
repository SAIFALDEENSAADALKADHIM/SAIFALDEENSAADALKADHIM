export const PUBLICATIONS = [
  { year: 2025, title: 'Three-electrode particle sensor optimization', venue: 'Sensors and Actuators A: Physical' },
  { year: 2025, title: 'Flexible materials for ionization-based aerosol sensors', venue: 'Sensors and Actuators A: Physical' },
  { year: 2025, title: 'Ionized particle sensor arrays for industrial emissions', venue: 'Sensors and Actuators B: Chemical' },
  { year: 2024, title: 'MEMS sensors for ultra-high voltage transmission systems', venue: 'IEEE APEC Conference' },
  { year: 2021, title: 'Gravel silo monitoring for construction-waste reduction', venue: 'Journal of Physics: Conference Series' },
  { year: 2017, title: 'Implementation of CNC machine via wireless IoT technology', venue: 'UKSim-AMSS' },
];
