export const SKILLS = [
  {
    cat: 'Design & simulation',
    items: ['Altium Designer', 'Eagle', 'Flux.ai', 'DeepPCB', 'Quilter', 'CST Studio', 'MATLAB / Simulink', 'COMSOL'],
  },
  {
    cat: 'Fabrication & characterization',
    items: ['MEMS lithography', 'CNT growth', 'Silicon micropillars', 'Three-electrode assembly', 'Humidity · aerosol · UHV testing'],
  },
  {
    cat: 'Software & data',
    items: ['JavaScript', 'Python', 'Deno', 'HTML/CSS', 'LaTeX', 'NotebookLM'],
  },
  {
    cat: 'Standards & systems',
    items: ['IEEE standards development', 'Blockchain / DLT frameworks', 'IoT protocols', 'I²C · SPI · MQTT'],
  },
];
