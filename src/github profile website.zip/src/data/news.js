// Curated fallback items. News.jsx merges these with live GitHub/ORCID activity.
export const NEWS = [
  { date: 'Mar 2026', tag: 'Publication', title: 'Three-electrode particle sensor — published', body: 'Optimization paper accepted in Sensors & Actuators A: Physical.' },
  { date: 'Feb 2026', tag: 'Standards',   title: 'IEEE P2418.11 — draft update', body: 'Working-group meeting finalised the next draft of the blockchain-based physical digital assets framework.' },
  { date: 'Nov 2025', tag: 'Talk',        title: 'MEMS colloquium — Xi’an Jiaotong University', body: 'Invited talk on ionization-based aerosol sensing for battery safety.' },
  { date: 'Sep 2025', tag: 'Milestone',   title: '200+ citations', body: 'Cumulative citations across publications crossed the 200 mark.' },
];
