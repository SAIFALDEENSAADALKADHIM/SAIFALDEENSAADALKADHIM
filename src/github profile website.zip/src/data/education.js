export const EDUCATION = [
  {
    degree: 'Ph.D., Electrical Engineering',
    inst: "Xi'an Jiaotong University",
    loc: 'China',
    period: '2020 — 2026',
    focus: 'MEMS ionization sensors · CNT-based sensing · Li-ion battery safety',
  },
  {
    degree: 'M.Sc., Electro-Mechanical System Engineering',
    inst: 'University of Technology, Baghdad',
    loc: 'Iraq',
    focus: '“Application of CNC machine based on IoT system” — low-cost microcontroller viability for industrial machining',
  },
  {
    degree: 'H.D., Power System Technology',
    inst: 'MTU — College of Electrical & Electronic Technology',
    loc: 'Iraq',
    focus: '“Simulation of multi-machine transient stability” — power network reliability',
  },
  {
    degree: 'B.Sc., Electrical Engineering',
    inst: 'University of Babylon',
    loc: 'Iraq',
    focus: 'Circuit design · power systems · electronics fundamentals',
  },
];
