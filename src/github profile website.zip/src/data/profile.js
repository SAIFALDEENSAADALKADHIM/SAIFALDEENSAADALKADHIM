export const PROFILE = {
  name: 'Saif Aldeen Saad Al-Kadhim',
  credential: 'Ph.D.',
  location: 'Budapest, Hungary',
  email: 'saifaldeen.saad@ieee.org',
  phone: '(+36) 20 400 8819',
  roles: [
    'Assistant Professor',
    'IEEE Senior Member',
    'Chair · IEEE YP Iraq Section',
    'MEMS Researcher',
    'Blockchain Standards Leader',
  ],
  bio: 'Bridging micro-nano fabrication, sensor intelligence, and global technical standards. I lead IEEE P2418.11 on blockchain-based physical digital assets, and conduct research on MEMS ionization sensors for battery safety, environmental monitoring, and industrial IoT.',
  social: {
    github: 'https://github.com/SAIFALDEENSAADALKADHIM',
    scholar: 'https://scholar.google.com/citations?user=3rVW_uYAAAAJ',
    researchgate: 'https://www.researchgate.net/profile/Saif-Aldeen-Alkadhim',
    ieee: 'https://www.ieee.org/',
    linkedin: 'https://linkedin.com',
  },
};

export const STATS = [
  { value: 137, suffix: '+', label: 'Publications' },
  { value: 200, suffix: '+', label: 'Citations' },
  { value: 35,  suffix: '+', label: 'IEEE communities' },
  { value: 50,  suffix: '+', label: 'PCB designs' },
];
