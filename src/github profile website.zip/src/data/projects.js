import cntHumidity from '../assets/projects/cnt-humidity.jpg';
import ionizationLiion from '../assets/projects/ionization-liion.jpg';
import flexibleMaterials from '../assets/projects/flexible-materials.jpg';
import memsUhv from '../assets/projects/mems-uhv.jpg';
import cncIot from '../assets/projects/cnc-iot.png';
import gravelSilo from '../assets/projects/gravel-silo.jpg';

export const PROJECTS = [
  {
    featured: true,
    title: 'Triple-electrode CNT humidity sensor',
    venue: 'Sensors & Actuators A: Physical, 2025',
    desc: 'A triple-electrode ionization sensor using silicon-strip substrates with carbon nanotube growth and electric-field regulation — achieving a record sensitivity of 381.67 %RH⁻¹ in nitrogen, with an 11-second response and 5-second recovery.',
    metrics: [
      { k: 'Sensitivity (N₂)', v: '381.67 %RH⁻¹' },
      { k: 'Response / recovery', v: '11 s / 5 s' },
      { k: 'Detection range', v: '25.8 – 100% RH' },
    ],
    img: cntHumidity,
    tags: ['MEMS', 'CNT', 'Humidity'],
    placeholder: 'Micrograph — three-electrode CNT array',
  },
  {
    title: 'Ionization aerosol sensor for Li-ion battery safety',
    venue: 'Sensors & Actuators B: Chemical, 2025',
    desc: 'Detects trace aerosols from thermal-runaway precursors in lithium-ion cells — invisible to conventional sensors — enabling real-time safety monitoring in EV and energy-storage systems.',
    img: ionizationLiion,
    tags: ['Safety', 'IoT', 'Sensors'],
  },
  {
    title: 'Flexible materials for ionization aerosol sensors',
    venue: 'Sensors & Actuators A: Physical, 2025',
    desc: 'Flexible-substrate fabrication process for ionization-based aerosol sensors, targeting wearable and conformal industrial deployment.',
    img: flexibleMaterials,
    tags: ['Flexible electronics', 'Fabrication'],
  },
  {
    title: 'MEMS sensors for ultra-high-voltage transmission',
    venue: 'IEEE APEC, 2024',
    desc: 'MEMS sensing architectures for partial-discharge and corona detection in UHV transmission — contributing to smart-grid monitoring and predictive maintenance.',
    img: memsUhv,
    tags: ['Smart grid', 'UHV', 'MEMS'],
  },
  {
    title: 'Wireless CNC controller via IoT',
    venue: 'UKSim-AMSS, 2017 · 49+ citations',
    desc: 'Remote CNC operation eliminating physical cabling in hazardous environments. Raspberry Pi and Arduino replace proprietary controllers, with centralised IoT monitoring.',
    img: cncIot,
    tags: ['IoT', 'CNC', 'Low-cost automation'],
  },
  {
    title: 'Gravel-silo monitoring for construction waste reduction',
    venue: 'J. Physics: Conf. Series, 2021',
    desc: 'Infrastructure-scale monitoring solution for aggregate silos — reduces construction waste and improves material traceability across sites.',
    img: gravelSilo,
    tags: ['Infrastructure', 'Monitoring'],
  },
];
