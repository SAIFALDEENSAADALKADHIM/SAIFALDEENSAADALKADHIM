import { useEffect, useState } from 'react'
import './News.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { NEWS } from '../../data/news'
import { fetchGithubEvents, fetchOrcidWorks, fmtRel } from '../ScienceHub/ScienceHub'

// Builds live items from real GitHub activity + ORCID works, merged with curated NEWS.
async function buildLiveItems() {
  const [events, works] = await Promise.all([fetchGithubEvents(), fetchOrcidWorks()])
  const live = []
  events.filter(e => e.type === 'CreateEvent' && e.payload.ref_type === 'repository').slice(0, 2).forEach(e => {
    live.push({ date: e.date, tag: 'Milestone', title: `New repository — ${e.repo}`, body: `Published ${fmtRel(e.date)} on GitHub.`, link: `https://github.com/${e.repo}` })
  })
  events.filter(e => e.type === 'ReleaseEvent').slice(0, 2).forEach(e => {
    live.push({ date: e.date, tag: 'Milestone', title: `Release ${e.payload.release && e.payload.release.tag_name} — ${e.repo}`, body: `Shipped ${fmtRel(e.date)}.`, link: `https://github.com/${e.repo}/releases` })
  })
  const currentYear = new Date().getFullYear()
  works.filter(w => parseInt(w.year || 0) >= currentYear - 1).slice(0, 2).forEach(w => {
    live.push({ date: w.year, tag: 'Publication', title: w.title, body: w.journal || 'New ORCID record.', link: w.url })
  })
  return live
}

export default function News() {
  const [items, setItems] = useState(NEWS)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    buildLiveItems().then((live) => {
      if (live.length) setItems([...live, ...NEWS].slice(0, 8))
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  return (
    <section className="s" id="news" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <SectionHead num="09" title="News" em="live from GitHub & ORCID · curated digest"
          sub="New repos, releases, and publications pulled live, layered over a curated digest of research and standards milestones." />
        <div className="news-meta">
          <span className="dot-live" />
          <span>{loading ? 'Checking live activity…' : 'Live + curated feed'}</span>
        </div>
        <div className="news-grid">
          {items.map((n, i) => {
            const Item = (
              <div className="news-item" key={n.title + i}>
                <div className="row">
                  <span className="date">{n.date}</span>
                  <span className="tag-s">{n.tag}</span>
                </div>
                <h4>{n.title}</h4>
                <p>{n.body}</p>
              </div>
            )
            return n.link ? <a href={n.link} target="_blank" rel="noreferrer" key={n.title + i} style={{ display: 'contents' }}>{Item}</a> : Item
          })}
        </div>
      </div>
    </section>
  )
}
