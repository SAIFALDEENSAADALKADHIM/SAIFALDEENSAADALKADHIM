import { useState } from 'react'
import './Header.css'
import { PROFILE } from '../../data/profile'

export default function Header() {
  const [open, setOpen] = useState(false)
  return (
    <header className="nav">
      <div className="wrap nav-inner">
        <a href="#top" className="nav-logo">Saif Al-Kadhim<em>, Ph.D.</em></a>
        <button className="nav-menu-btn" onClick={() => setOpen(!open)} aria-label="Menu">{open ? 'Close' : 'Menu'}</button>
        <nav className={`nav-links ${open ? 'open' : ''}`} onClick={() => setOpen(false)}>
          <a href="#work">Work</a>
          <a href="#projects">Projects</a>
          <a href="#software">Software</a>
          <a href="#ieee">IEEE</a>
          <a href="#publications">Publications</a>
          <a href="#partnerships">Partners</a>
          <a href="#sciencehub">Science</a>
          <a href="#news">News</a>
          <a href={`mailto:${PROFILE.email}`} className="cta">Contact</a>
        </nav>
      </div>
    </header>
  )
}
