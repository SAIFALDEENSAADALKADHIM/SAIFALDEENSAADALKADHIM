import './Education.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { EDUCATION } from '../../data/education'

export default function Education() {
  return (
    <section className="s" id="education" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <SectionHead num="02" title="Education" em="Babylon · Baghdad · Xi'an" />
        <div className="edu-grid">
          {EDUCATION.map((e) => (
            <div className="edu" key={e.degree}>
              {e.period && <span className="period">{e.period}</span>}
              <h3 className="degree">{e.degree}</h3>
              <div className="inst">{e.inst}</div>
              <div className="loc">{e.loc}</div>
              <p className="focus">{e.focus}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
