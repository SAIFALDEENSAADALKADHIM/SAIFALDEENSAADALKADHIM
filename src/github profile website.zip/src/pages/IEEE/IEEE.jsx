import './IEEE.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { IEEE_WORK } from '../../data/ieee'

export default function IEEE() {
  return (
    <section className="ieee" id="ieee">
      <div className="wrap">
        <SectionHead num="06" title="Standards & leadership" em="from Iraq Section YP to global blockchain standards"
          sub="I chair IEEE Young Professionals for the Iraq Section and serve as Vice Chair of the IEEE P2418.11 Working Group, developing the international framework for blockchain-based physical digital assets with a focus on secure e-voting." />
        <div className="ieee-roles">
          {IEEE_WORK.roles.map((r) => (
            <div className="ieee-role-row" key={r.k}>
              <span className="ieee-role-k">{r.k}</span>
              <span className="ieee-role-v">{r.v}</span>
            </div>
          ))}
        </div>
        <div className="ieee-standard">“{IEEE_WORK.standard}”</div>
        <div className="ieee-pillars">
          {IEEE_WORK.pillars.map((p, i) => (
            <div className="pillar" key={p.k}>
              <div className="num">0{i + 1}</div>
              <div className="k">{p.k}</div>
              <div className="v">{p.v}</div>
            </div>
          ))}
        </div>
        <div className="awards">
          {IEEE_WORK.awards.map((a) => <span key={a}>{a}</span>)}
        </div>
      </div>
    </section>
  )
}
