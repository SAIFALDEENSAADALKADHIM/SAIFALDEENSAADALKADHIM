import './Stats.css'
import { STATS } from '../../data/profile'
import { AnimatedNumber } from '../../hooks/AnimatedNumber'

export default function Stats() {
  return (
    <section className="stats">
      <div className="wrap">
        <div className="stats-grid">
          {STATS.map((s) => (
            <div className="stat" key={s.label}>
              <div className="v"><AnimatedNumber value={s.value} /><span className="suf">{s.suffix}</span></div>
              <div className="l">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
