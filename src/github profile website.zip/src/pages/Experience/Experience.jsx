import './Experience.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { EXPERIENCE } from '../../data/experience'

export default function Experience() {
  return (
    <section className="s" id="work">
      <div className="wrap">
        <SectionHead num="01" title="Experience" em="a decade across research, academia, and industry"
          sub="Selected positions across MEMS research, university teaching, government project leadership, and industrial electronics." />
        <div className="tl-items">
          {EXPERIENCE.map((e) => (
            <div className="tl-item" key={e.role + e.org}>
              <div className="tl-period">{e.period}</div>
              <div>
                <h3 className="tl-role">{e.role}</h3>
                <div className="tl-org">{e.org}</div>
                <div className="tl-loc">{e.location}</div>
                <p className="tl-desc">{e.desc}</p>
                <div className="tags">{e.tags.map((t) => <span key={t} className="tag">{t}</span>)}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
