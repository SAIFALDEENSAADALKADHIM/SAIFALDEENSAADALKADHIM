import './Publications.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { PUBLICATIONS } from '../../data/publications'
import { PROFILE } from '../../data/profile'

export default function Publications() {
  return (
    <section className="s" id="publications">
      <div className="wrap">
        <SectionHead num="07" title="Publications" em="peer-reviewed journals and conferences"
          sub="A selection of recent work. Full list on Google Scholar." />
        <div className="pubs">
          {PUBLICATIONS.map((p) => (
            <a href={PROFILE.social.scholar} target="_blank" rel="noreferrer" className="pub" key={p.title}>
              <div className="yr">{p.year}</div>
              <div>
                <div className="tt">{p.title}</div>
                <div className="ve">{p.venue}</div>
              </div>
              <div className="ext">View ↗</div>
            </a>
          ))}
        </div>
        <div style={{ marginTop: 28 }}>
          <a className="btn" href={PROFILE.social.scholar} target="_blank" rel="noreferrer">View full list on Google Scholar ↗</a>
        </div>
      </div>
    </section>
  )
}
