import './Skills.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { SKILLS } from '../../data/skills'

export default function Skills() {
  return (
    <section className="s" id="skills" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <SectionHead num="05" title="Other expertise" em="design, fabrication, and the systems in between" />
        <div className="skills-grid">
          {SKILLS.map((s) => (
            <div className="sk" key={s.cat}>
              <h4>{s.cat}</h4>
              <ul>{s.items.map((i) => <li key={i}>{i}</li>)}</ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
