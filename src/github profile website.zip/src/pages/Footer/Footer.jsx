import './Footer.css'
import { PROFILE } from '../../data/profile'

export default function Footer() {
  return (
    <footer>
      <div className="wrap">
        <div className="foot-grid">
          <div className="foot-motto">
            “Bridging engineering disciplines and regions — advancing technology for humanity through academic rigor, institutional leadership, and pioneering research.”
          </div>
          <div className="foot-col">
            <h5>Contact</h5>
            <a href={`mailto:${PROFILE.email}`}>{PROFILE.email}</a>
            <span>{PROFILE.phone}</span>
            <span>{PROFILE.location}</span>
          </div>
          <div className="foot-col">
            <h5>Elsewhere</h5>
            <a href={PROFILE.social.scholar} target="_blank" rel="noreferrer">Google Scholar ↗</a>
            <a href={PROFILE.social.researchgate} target="_blank" rel="noreferrer">ResearchGate ↗</a>
            <a href={PROFILE.social.github} target="_blank" rel="noreferrer">GitHub ↗</a>
            <a href={PROFILE.social.linkedin} target="_blank" rel="noreferrer">LinkedIn ↗</a>
          </div>
        </div>
        <div className="foot-bottom">
          <span>© {new Date().getFullYear()} Saif Aldeen Saad Al-Kadhim</span>
          <span>Updated {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
        </div>
      </div>
    </footer>
  )
}
