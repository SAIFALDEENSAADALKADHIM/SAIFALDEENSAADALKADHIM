import './Projects.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { PROJECTS } from '../../data/projects'

export default function Projects() {
  const [featured, ...rest] = PROJECTS
  return (
    <section className="s" id="projects" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <SectionHead num="03" title="Selected projects" em="sensor intelligence at the micro-nano scale"
          sub="Featured work spans MEMS ionization sensors, carbon-nanotube humidity sensing, and IoT-driven industrial automation." />

        <div className="feat">
          <div>
            <div className="feat-label">Featured · record sensitivity</div>
            <h3 className="feat-title">{featured.title}</h3>
            <div className="feat-venue">{featured.venue}</div>
            <p className="feat-desc">{featured.desc}</p>
          </div>
          <div>
            <div className="feat-img-photo">
              <img src={featured.img} alt={featured.placeholder} />
              <div className="feat-img-cap">{featured.placeholder}</div>
            </div>
            <div className="feat-metrics">
              {featured.metrics.map((m) => (
                <div className="feat-metric" key={m.k}>
                  <span className="k">{m.k}</span>
                  <span className="v">{m.v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="proj-list">
          {rest.map((p) => (
            <article className="pcard" key={p.title}>
              <div className="p-visual"><img src={p.img} alt={p.title} /></div>
              <div className="p-body">
                <div className="p-year">{(p.venue.match(/\d{4}/) || [''])[0]}</div>
                <h3 className="p-title">{p.title}</h3>
                <div className="p-venue">{p.venue}</div>
                <p className="p-desc">{p.desc}</p>
                <div className="p-tags tags">{p.tags.map((t) => <span key={t} className="tag">{t}</span>)}</div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
