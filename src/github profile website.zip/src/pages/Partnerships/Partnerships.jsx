import './Partnerships.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { PARTNERSHIPS } from '../../data/partnerships'
import { PROFILE } from '../../data/profile'

export default function Partnerships() {
  return (
    <section className="s partners-s" id="partnerships" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <SectionHead num="07" title="Industry & partnerships" em="IEEE PES Young Professionals" sub={PARTNERSHIPS.tagline} />
        <div className="partners-role">{PARTNERSHIPS.role}</div>
        <p className="partners-who">{PARTNERSHIPS.who}</p>

        <div className="partners-sub">2026 engagement focus</div>
        <div className="partners-focus">
          {PARTNERSHIPS.focus2026.map((f, i) => (
            <div className="focus-row" key={f.k}>
              <span className="focus-num">0{i + 1}</span>
              <span className="focus-k">{f.k}</span>
              <span className="focus-v">{f.v}</span>
            </div>
          ))}
        </div>

        <div className="partners-sub">What collaboration can include</div>
        <div className="partners-collab">
          {PARTNERSHIPS.collab.map((c) => <span key={c} className="collab-chip">{c}</span>)}
        </div>

        <div className="partners-cta">
          <div>
            <div className="cta-label">Partnership coordinator</div>
            <div className="cta-name">Saif Aldeen Al-Kadhim — IEEE Senior Member</div>
          </div>
          <a className="btn btn-primary" href={`mailto:${PROFILE.email}?subject=IEEE%20PES%20YP%20Partnership%20Inquiry`}>Start a conversation ↗</a>
        </div>
      </div>
    </section>
  )
}
