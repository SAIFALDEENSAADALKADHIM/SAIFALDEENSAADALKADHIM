import { useEffect, useState } from 'react'
import './Hero.css'
import { PROFILE } from '../../data/profile'
import portrait from '../../assets/portrait.jpg'

export default function Hero() {
  const [idx, setIdx] = useState(0)
  const [vis, setVis] = useState(true)
  useEffect(() => {
    const iv = setInterval(() => {
      setVis(false)
      setTimeout(() => {
        setIdx((i) => (i + 1) % PROFILE.roles.length)
        setVis(true)
      }, 350)
    }, 2800)
    return () => clearInterval(iv)
  }, [])

  return (
    <section className="hero wrap" id="top">
      <div className="hero-tag"><span className="dot" />{PROFILE.location} · Available for collaboration</div>
      <div className="hero-grid">
        <div>
          <h1 className="hero-name">
            Saif Aldeen<br />Saad Al-Kadhim
            <span className="cred">{PROFILE.credential}</span>
          </h1>
          <div className="hero-roles" aria-live="polite">
            <span className="hero-role-word" style={{ opacity: vis ? 1 : 0, transform: vis ? 'translateY(0)' : 'translateY(-6px)' }}>
              {PROFILE.roles[idx]}
            </span>
          </div>
          <p className="hero-bio">{PROFILE.bio}</p>

          <div className="hero-meta">
            <div><span className="k">Affiliation</span>Xi'an Jiaotong Univ. — IEMIT Lab</div>
            <div><span className="k">Email</span><a href={`mailto:${PROFILE.email}`}>{PROFILE.email}</a></div>
            <div><span className="k">IEEE</span>YP Iraq Chair · P2418.11 Vice Chair</div>
          </div>

          <div className="hero-actions">
            <a className="btn btn-primary" href={PROFILE.social.scholar} target="_blank" rel="noreferrer">Google Scholar ↗</a>
            <a className="btn" href={PROFILE.social.researchgate} target="_blank" rel="noreferrer">ResearchGate ↗</a>
            <a className="btn" href={PROFILE.social.github} target="_blank" rel="noreferrer">GitHub ↗</a>
            <a className="btn btn-ghost" href={`mailto:${PROFILE.email}`}>Email</a>
          </div>
        </div>

        <div>
          <div className="portrait-photo" role="img" aria-label="Portrait of Saif Al-Kadhim">
            <img src={portrait} alt="Portrait of Saif Al-Kadhim" />
          </div>
        </div>
      </div>
    </section>
  )
}
