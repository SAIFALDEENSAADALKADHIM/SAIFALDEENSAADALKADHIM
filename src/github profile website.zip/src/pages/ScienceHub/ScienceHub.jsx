import { useEffect, useState } from 'react'
import './ScienceHub.css'
import SectionHead from '../../components/SectionHead/SectionHead'

const ORCID_ID = '0000-0002-2082-9591'
const GH_USER = 'SAIFALDEENSAADALKADHIM'

async function fetchJson(url, opts = {}) {
  try {
    const r = await fetch(url, { headers: { Accept: 'application/json' }, ...opts })
    if (!r.ok) throw new Error(String(r.status))
    return await r.json()
  } catch (e) { return null }
}

async function fetchArxivFeed(searchQuery, max = 6) {
  const feed = `http://export.arxiv.org/api/query?search_query=${encodeURIComponent(searchQuery)}&sortBy=submittedDate&sortOrder=descending&max_results=${max}`
  const url = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(feed)}`
  const data = await fetchJson(url)
  if (!data || !data.items) return []
  return data.items.map(it => ({
    title: it.title, link: it.link, date: (it.pubDate || '').slice(0, 10),
    authors: (it.author || '').split(',').slice(0, 3).map(s => s.trim()).filter(Boolean).join(', '),
    summary: (it.description || '').replace(/<[^>]+>/g, '').slice(0, 220),
  }))
}

export async function fetchOrcidWorks() {
  const url = `https://pub.orcid.org/v3.0/${ORCID_ID}/works`
  const data = await fetchJson(url)
  if (!data || !data.group) return []
  const works = data.group.map(g => {
    const s = g['work-summary'] && g['work-summary'][0]
    if (!s) return null
    const title = s.title && s.title.title ? s.title.title.value : 'Untitled'
    const journal = s['journal-title'] ? s['journal-title'].value : ''
    const year = s['publication-date'] && s['publication-date'].year ? s['publication-date'].year.value : ''
    let doi = ''
    const ids = s['external-ids'] && s['external-ids']['external-id'] || []
    const doiObj = ids.find(i => (i['external-id-type'] || '').toLowerCase() === 'doi')
    if (doiObj) doi = doiObj['external-id-value']
    const url2 = doi ? `https://doi.org/${doi}` : (s.url && s.url.value) || ''
    return { title, journal, year, doi, url: url2, type: s.type || 'publication' }
  }).filter(Boolean)
  works.sort((a, b) => (parseInt(b.year || 0) - parseInt(a.year || 0)))
  return works
}

export async function fetchGithubRepos() {
  const data = await fetchJson(`https://api.github.com/users/${GH_USER}/repos?sort=updated&per_page=12`)
  if (!Array.isArray(data)) return []
  return data.map(r => ({
    name: r.name, desc: r.description, url: r.html_url,
    stars: r.stargazers_count, lang: r.language, updated: (r.updated_at || '').slice(0, 10),
    isFork: r.fork, topics: r.topics || [],
  }))
}
export async function fetchGithubEvents() {
  const data = await fetchJson(`https://api.github.com/users/${GH_USER}/events/public?per_page=30`)
  if (!Array.isArray(data)) return []
  return data.map(e => ({
    type: e.type, repo: e.repo && e.repo.name, date: (e.created_at || '').slice(0, 10),
    payload: e.payload || {},
  }))
}
async function fetchGithubTrending() {
  const q = 'topic:science+topic:research+pushed:>2025-01-01'
  const url = `https://api.github.com/search/repositories?q=${q}&sort=stars&order=desc&per_page=6`
  const data = await fetchJson(url)
  if (!data || !data.items) return []
  return data.items.map(r => ({
    name: r.full_name, desc: r.description, url: r.html_url,
    stars: r.stargazers_count, lang: r.language, updated: (r.pushed_at || '').slice(0, 10),
  }))
}

function Spinner({ label = 'Loading feed…' }) {
  return (
    <div className="sh-spinner">
      <span className="sh-dot" /><span className="sh-dot" /><span className="sh-dot" />
      <span className="sh-spinner-label">{label}</span>
    </div>
  )
}
function EmptyState({ title, body, hint }) {
  return (
    <div className="sh-empty">
      <div className="sh-empty-title">{title}</div>
      <div className="sh-empty-body">{body}</div>
      {hint && <div className="sh-empty-hint">{hint}</div>}
    </div>
  )
}
export function fmtRel(dateStr) {
  if (!dateStr) return ''
  const d = new Date(dateStr)
  const diff = (Date.now() - d.getTime()) / 86400000
  if (diff < 1) return 'today'
  if (diff < 2) return 'yesterday'
  if (diff < 30) return `${Math.floor(diff)}d ago`
  if (diff < 365) return `${Math.floor(diff / 30)}mo ago`
  return `${Math.floor(diff / 365)}y ago`
}

function TabMyWork() {
  const [orcid, setOrcid] = useState(null)
  const [repos, setRepos] = useState(null)
  const [events, setEvents] = useState(null)

  useEffect(() => {
    fetchOrcidWorks().then(setOrcid)
    fetchGithubRepos().then(setRepos)
    fetchGithubEvents().then(setEvents)
  }, [])

  const recentReleases = (events || []).filter(e => e.type === 'ReleaseEvent').slice(0, 3)
  const recentRepos = (events || []).filter(e => e.type === 'CreateEvent' && e.payload.ref_type === 'repository').slice(0, 3)

  return (
    <div className="sh-tab">
      <div className="sh-lane">
        <div className="sh-lane-head">
          <div className="sh-lane-num">01</div>
          <div>
            <div className="sh-lane-title">Publications (ORCID)</div>
            <div className="sh-lane-sub">Live feed from ORCID {ORCID_ID}</div>
          </div>
          <a className="sh-lane-link" href={`https://orcid.org/${ORCID_ID}`} target="_blank" rel="noreferrer">Open ORCID ↗</a>
        </div>
        {orcid === null && <Spinner label="Fetching ORCID works…" />}
        {orcid && orcid.length === 0 && <EmptyState title="No works yet" body="ORCID returned an empty record." />}
        {orcid && orcid.length > 0 && (
          <ol className="sh-pub-list">
            {orcid.slice(0, 10).map((w, i) => (
              <li key={i} className="sh-pub-row">
                <div className="sh-pub-year">{w.year || '—'}</div>
                <div className="sh-pub-body">
                  <a href={w.url || '#'} target="_blank" rel="noreferrer" className="sh-pub-title">{w.title}</a>
                  <div className="sh-pub-meta">
                    {w.journal && <span>{w.journal}</span>}
                    {w.doi && <span className="sh-mono">· DOI {w.doi}</span>}
                    <span className="sh-mono sh-type">· {w.type.replace(/_/g, ' ').toLowerCase()}</span>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        )}
      </div>

      <div className="sh-lane">
        <div className="sh-lane-head">
          <div className="sh-lane-num">02</div>
          <div>
            <div className="sh-lane-title">Latest from GitHub</div>
            <div className="sh-lane-sub">New repos, releases, and active projects</div>
          </div>
          <a className="sh-lane-link" href={`https://github.com/${GH_USER}`} target="_blank" rel="noreferrer">@{GH_USER} ↗</a>
        </div>
        {repos === null && <Spinner label="Fetching repositories…" />}
        {repos && repos.length === 0 && <EmptyState title="No public repos" body="Either rate-limited or none indexed yet." />}
        {repos && repos.length > 0 && (
          <>
            {(recentReleases.length > 0 || recentRepos.length > 0) && (
              <div className="sh-events">
                {recentRepos.map((e, i) => (
                  <a key={'r' + i} className="sh-event sh-event-new" href={`https://github.com/${e.repo}`} target="_blank" rel="noreferrer">
                    <span className="sh-event-tag">NEW REPO</span>
                    <span className="sh-event-name">{e.repo}</span>
                    <span className="sh-event-date">{fmtRel(e.date)}</span>
                  </a>
                ))}
                {recentReleases.map((e, i) => (
                  <a key={'rl' + i} className="sh-event sh-event-rel" href={`https://github.com/${e.repo}/releases`} target="_blank" rel="noreferrer">
                    <span className="sh-event-tag">RELEASE</span>
                    <span className="sh-event-name">{e.repo} · {e.payload.release && e.payload.release.tag_name}</span>
                    <span className="sh-event-date">{fmtRel(e.date)}</span>
                  </a>
                ))}
              </div>
            )}
            <div className="sh-repos">
              {repos.filter(r => !r.isFork).slice(0, 6).map(r => (
                <a key={r.name} className="sh-repo" href={r.url} target="_blank" rel="noreferrer">
                  <div className="sh-repo-top">
                    <div className="sh-repo-name">{r.name}</div>
                    <div className="sh-repo-stars">★ {r.stars}</div>
                  </div>
                  <div className="sh-repo-desc">{r.desc || <span className="sh-muted">No description</span>}</div>
                  <div className="sh-repo-meta">
                    {r.lang && <span className="sh-repo-lang">{r.lang}</span>}
                    <span className="sh-mono">updated {fmtRel(r.updated)}</span>
                  </div>
                </a>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function TabTrending() {
  const [trending, setTrending] = useState(null)
  useEffect(() => { fetchGithubTrending().then(setTrending) }, [])

  return (
    <div className="sh-tab">
      <div className="sh-lane">
        <div className="sh-lane-head">
          <div className="sh-lane-num">01</div>
          <div>
            <div className="sh-lane-title">Trending in science on GitHub</div>
            <div className="sh-lane-sub">Top-starred repos tagged <span className="sh-mono">science</span> · <span className="sh-mono">research</span></div>
          </div>
          <a className="sh-lane-link" href="https://github.com/topics/science" target="_blank" rel="noreferrer">View all ↗</a>
        </div>
        {trending === null && <Spinner label="Fetching trending repos…" />}
        {trending && trending.length === 0 && <EmptyState title="No results" body="Rate-limited or no matches." />}
        {trending && trending.length > 0 && (
          <ol className="sh-trending">
            {trending.map((r, i) => (
              <li key={r.name} className="sh-trend-row">
                <div className="sh-trend-rank">{String(i + 1).padStart(2, '0')}</div>
                <div className="sh-trend-body">
                  <a className="sh-trend-name" href={r.url} target="_blank" rel="noreferrer">{r.name}</a>
                  <div className="sh-trend-desc">{r.desc || <span className="sh-muted">No description</span>}</div>
                  <div className="sh-trend-meta">
                    {r.lang && <span>{r.lang}</span>}
                    <span className="sh-mono">★ {r.stars.toLocaleString()}</span>
                    <span className="sh-mono">updated {fmtRel(r.updated)}</span>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        )}
      </div>

      <div className="sh-lane">
        <div className="sh-lane-head">
          <div className="sh-lane-num">02</div>
          <div>
            <div className="sh-lane-title">What to read</div>
            <div className="sh-lane-sub">Quick jumps into active communities and dashboards</div>
          </div>
        </div>
        <div className="sh-jumps">
          <a className="sh-jump" href="https://arxiv.org/list/eess.SP/recent" target="_blank" rel="noreferrer">
            <div className="sh-jump-k">arXiv eess.SP</div><div className="sh-jump-v">Signal processing — new today</div>
          </a>
          <a className="sh-jump" href="https://arxiv.org/list/physics.ins-det/recent" target="_blank" rel="noreferrer">
            <div className="sh-jump-k">arXiv physics.ins-det</div><div className="sh-jump-v">Instrumentation & detectors</div>
          </a>
          <a className="sh-jump" href="https://www.nature.com/subjects/electrical-and-electronic-engineering" target="_blank" rel="noreferrer">
            <div className="sh-jump-k">Nature — EEE</div><div className="sh-jump-v">Editors' picks</div>
          </a>
          <a className="sh-jump" href="https://ieeexplore.ieee.org/Xplore/home.jsp" target="_blank" rel="noreferrer">
            <div className="sh-jump-k">IEEE Xplore</div><div className="sh-jump-v">Journals & proceedings</div>
          </a>
          <a className="sh-jump" href="https://www.semanticscholar.org/" target="_blank" rel="noreferrer">
            <div className="sh-jump-k">Semantic Scholar</div><div className="sh-jump-v">AI-powered paper search</div>
          </a>
          <a className="sh-jump" href="https://github.com/trending" target="_blank" rel="noreferrer">
            <div className="sh-jump-k">GitHub trending</div><div className="sh-jump-v">Daily, weekly, monthly</div>
          </a>
        </div>
      </div>
    </div>
  )
}

function TabDiscoveries() {
  const [field, setField] = useState(null)
  const [general, setGeneral] = useState(null)

  useEffect(() => {
    fetchArxivFeed('all:"power electronics" OR all:"microgrid" OR all:"MEMS sensor" OR all:"ionization"').then(setField)
    fetchArxivFeed('cat:physics.ins-det OR cat:eess.SY OR cat:cs.AI').then(setGeneral)
  }, [])

  function Lane({ items, title, sub, num, link, linkLabel }) {
    return (
      <div className="sh-lane">
        <div className="sh-lane-head">
          <div className="sh-lane-num">{num}</div>
          <div>
            <div className="sh-lane-title">{title}</div>
            <div className="sh-lane-sub">{sub}</div>
          </div>
          {link && <a className="sh-lane-link" href={link} target="_blank" rel="noreferrer">{linkLabel} ↗</a>}
        </div>
        {items === null && <Spinner label="Fetching latest papers…" />}
        {items && items.length === 0 && <EmptyState title="Feed unavailable" body="arXiv proxy returned no items (or the feed is rate-limiting). Try again shortly." />}
        {items && items.length > 0 && (
          <ul className="sh-disc">
            {items.slice(0, 6).map((p, i) => (
              <li key={i} className="sh-disc-row">
                <div className="sh-disc-date">{p.date}</div>
                <div className="sh-disc-body">
                  <a className="sh-disc-title" href={p.link} target="_blank" rel="noreferrer">{p.title}</a>
                  <div className="sh-disc-authors">{p.authors}</div>
                  <div className="sh-disc-summary">{p.summary}…</div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    )
  }

  return (
    <div className="sh-tab">
      <Lane items={field} num="01" title="In your fields" sub="Power electronics · microgrids · MEMS sensors · ionization"
        link="https://arxiv.org/list/eess.SY/recent" linkLabel="Browse arXiv" />
      <Lane items={general} num="02" title="General discoveries" sub="Instrumentation · systems · AI — today's preprints"
        link="https://arxiv.org/list/physics.ins-det/recent" linkLabel="All physics" />
    </div>
  )
}

export default function ScienceHub() {
  const [tab, setTab] = useState('work')
  const tabs = [
    { id: 'work', label: 'My work', sub: 'ORCID + GitHub' },
    { id: 'trending', label: 'Trending', sub: 'GitHub science' },
    { id: 'discover', label: 'Discoveries', sub: 'Fresh preprints' },
  ]

  return (
    <section className="s sh-s" id="sciencehub" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <SectionHead num="08" title="Science hub" em="everything for researchers"
          sub="Live feeds from ORCID, GitHub, and arXiv — updated every time the page loads." />
        <div className="sh-tabs" role="tablist">
          {tabs.map(t => (
            <button key={t.id} role="tab" aria-selected={tab === t.id}
              className={'sh-tab-btn ' + (tab === t.id ? 'is-active' : '')}
              onClick={() => setTab(t.id)}>
              <span className="sh-tab-label">{t.label}</span>
              <span className="sh-tab-sub">{t.sub}</span>
            </button>
          ))}
          <div className="sh-live"><span className="sh-live-dot" /> LIVE</div>
        </div>
        {tab === 'work' && <TabMyWork />}
        {tab === 'trending' && <TabTrending />}
        {tab === 'discover' && <TabDiscoveries />}
      </div>
    </section>
  )
}
