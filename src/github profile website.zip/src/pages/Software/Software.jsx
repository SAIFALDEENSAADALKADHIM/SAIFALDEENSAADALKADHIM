import './Software.css'
import SectionHead from '../../components/SectionHead/SectionHead'
import { SOFTWARE_STORY } from '../../data/software'
import { useInView } from '../../hooks/useInView'

function StoryChapter({ chapter: c, idx, total }) {
  const [ref, inView] = useInView({ threshold: 0.25, once: true })
  return (
    <article ref={ref} className={`chapter ${inView ? 'in' : ''}`}>
      <div className="ch-num-col">
        <div className="ch-dot" />
        <div className="ch-num">Ch. {c.ch}</div>
        <div className="ch-era">{c.era}</div>
      </div>
      <div className="ch-body">
        <div className="ch-drop">{c.title[0]}</div>
        <h3 className="ch-title">{c.title}</h3>
        <div className="ch-scene">{c.scene}</div>
        <p className="ch-narration">{c.narration}</p>
        <div className="ch-tools">
          {c.tools.map((t) => <span key={t} className="ch-tool">{t}</span>)}
        </div>
        {idx < total - 1 && <div className="ch-ornament">· · ·</div>}
      </div>
    </article>
  )
}

export default function Software() {
  return (
    <section className="s story-s" id="software" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <SectionHead num="04" title="Software, a story" em="how the toolchain grew over twenty years"
          sub="Not a skill list — a chronology. The tools I trust were earned one project at a time." />
        <div className="story">
          <div className="story-rail" aria-hidden="true" />
          {SOFTWARE_STORY.map((c, i) => (
            <StoryChapter key={c.ch} chapter={c} idx={i} total={SOFTWARE_STORY.length} />
          ))}
          <div className="story-end">
            <span>End of chapter</span>
            <span>· next write-up soon ·</span>
          </div>
        </div>
      </div>
    </section>
  )
}
